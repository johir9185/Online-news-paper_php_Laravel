<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

use App\Model_beraking_news;

use Auth;
use Session;

class Breaking_news_cont extends Controller
{
     public function show1(){

        return view('breaking_and_salat.breaking_data_sent');   


   }
    
    public function show2(Request $request){
    
          $news = $request->input('news');
          

           $this->validate($request, [
                 
                  'news' => 'required'
                
                 
              ]);


          $user =  Model_beraking_news::find(1);

           
                 $user->name =$news;

                 $user->save();      
     
           



            Session::flash('flash_message_insert_beaking_news', 'Task successfully added!');

            return redirect()->back();


	     
	}

}
