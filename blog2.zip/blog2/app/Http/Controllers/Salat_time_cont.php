<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;

use App\Model_salat_time;

use Auth;
use Session;

class Salat_time_cont extends Controller
{
     public function show1(){

        return view('breaking_and_salat.salat_time_in');   


   }
    
    public function show2(Request $request){
    
          $fozor = $request->input('fozor');
           $zohor = $request->input('zohor');
            $asor = $request->input('asor');
             $magrib =$request->input('magrib');
              $esa = $request->input('esa');
               

                $this->validate($request, [
                 
                  'fozor' => 'required|max:255',
                  'zohor' => 'requiredmax:255',
                  'asor' => 'requiredmax:255',
                  'magrib' => 'requiredmax:255',
                  'esa' => 'requiredmax:255'
                
                 
              ]);



        $user =  Model_salat_time::find(1);

            $user->fozor =$fozor;
             $user->zohor =$zohor;
              $user->asor = $asor;
               $user->magrib = $magrib;
                $user->esa= $esa;
                

                 $user->save();    

         




            Session::flash('flash_message_insert_salat', 'Task successfully added!');

            return redirect()->back();


	   
	}

}
