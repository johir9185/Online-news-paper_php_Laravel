<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Http\Requests;

use DB;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Input;
use Illuminate\Support\Facades\Redirect;
use Illuminate\Support\Facades\Validator;


use App\Model_read_bd;
use Auth;

use App\Model_read_sports;
use App\Model_read_international;
use App\Model_read_economy;

class Search_data_speccific_table_cont extends Controller
{
    
    public function show00()
    {

    	
    	return view('search_fol.search_data');   
    }

     public function show1(Request $request)
    {

           $title=$request->input('title');
            $table=$request->input('table');

          //  dd($table1);
  
              $this->validate($request, [
                 
                  'title' => 'required'
                
                 
              ]);

           $users;

           if($table=="bd"){
                    
                   $users = Model_read_bd::where('title', $title)->get();  

            }else if($table=="internation"){

            $users = Model_read_international::where('title', $title)->get();  

            }else if($table=="sports"){

             $users = Model_read_sports::where('title', $title)->get();  

            }

            else if($table=="economy"){

              $users = Model_read_economy::where('title', $title)->get();  

            }







       
          
         
        return view('update_fol.update_data')->with('data1', $users);

    }
}
