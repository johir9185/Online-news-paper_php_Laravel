<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Breaking News Insertion</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST"  action="<?php echo e(url('/breking_news_data_post')); ?>">
                        <?php echo e(csrf_field()); ?>


                      

                          <div class="form-group<?php echo e($errors->has('news') ? ' has-error' : ''); ?>">
                            <label for="news" class="col-md-4 control-label">Breaking News</label>

                            <div class="col-md-6">
                              <textarea class="form-control" rows="5" id="des" name="news"></textarea>

                                <?php if($errors->has('news')): ?>
                                    <span class="help-block">
                                        <strong><?php echo e($errors->first('news')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i> Update
                                </button>
                            </div>
                        </div>

                       <div class="col-md-12">
                            <?php if(Session::has('flash_message_insert_beaking_news')): ?>
                            <div class="alert alert-success">
                                <center><h3><?php echo e(Session::get('flash_message_insert_beaking_news')); ?><h3></center>
                                <?php echo e(Session::forget('flash_message_insert_beaking_news')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>