<!DOCTYPE html>
<html>



 
<head>
 <meta charset="UTF-8">
    <title></title>
    <script src="http://s.codepen.io/assets/libs/modernizr.js" type="text/javascript"></script>


<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.1.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

  <meta Http-Equiv="Cache-Control" Content="no-cache">
<meta Http-Equiv="Pragma" Content="no-cache">
<meta Http-Equiv="Expires" Content="0"> 

<style>

.head_main{
width: auto;
	height: 60px;

  background-color:#F5F5DC;   

	

}

.head_main2{
  width:1200px;
	margin:0 auto 0 auto;

}




.wrapper_p{


    width:1200px;
	margin:0 auto 0 auto;
	    background-color:#F5F5DC;      
	  
	  margin-top: 5%;

  
}

.content_p{

 width:900px;
	float:left;
	
	height:auto;
	  background-color:#F5F5DC;   

}

.sidebar_p{

width:300px;
	float:right;
	height:2500px;
 
      overflow: hidden;


}

.sidebar_margin{

  margin: 10px;
  padding: 10px;
  overflow: hidden;
}


.sp00{
 width:900px;
 height: auto;
 margin: 10px;
 overflow: hidden;
  background-color: #E6E6FA;
}

.sp0{
 width:900px;

 padding: 5px;
 margin: 5px;

height: auto;
 overflow: hidden;
  

}

.sp1{
  width:430px;
  	  
		float:left;
	padding: 5px;
 margin: 5px;

 height: auto;
  overflow: hidden;
   background-color: #E6E6FA;
}

.sp2{
  width:430px;

  float:right;
 
padding: 5px;
 margin: 5px;

 height: auto;

  overflow: hidden;
   background-color: #E6E6FA;

}


#board{
margin:10px;
width:150px;
background: 
    -webkit-linear-gradient(rgba(5, 610, 255, 0.4), rgba(135, 60, 255, 0.0) 80%),
    -webkit-linear-gradient(-45deg, rgba(120, 155, 255, 0.9) 25%, rgba(255, 160, 65, 0.9) 76%);

}



.title_name{
    width: 390px;
	float: top;
	padding: 2px;
	margin: 1px;

}

.img_lef{

	float: left;
	width: 160px;
	height: 150px;

}

.img_lef2{

	float: left;
	width: 60px;
	height: 60px;

}

.img_lef00{

	float: left;
	width: 320px;
	height: 150px;

}









.cf:before, .cf:after {
  content:" ";
  display: table;

}
.cf:after {
  clear: both;
}
.cf {
  *zoom: 1;
}
.menu {
  list-style:none;
   position:relative; top:0%; left:20%;
  margin-top: 55px;
  width: 800px;
  width: -moz-fit-content;
  width: -webkit-fit-content;
  width: fit-content;
}
.menu > li {
  background: #34495e;
  float: left;
  position: relative;
  -webkit-transform: skewX(25deg);
}
.menu a {
  display: block;
  color: #fff;
  text-transform: uppercase;
  text-decoration: none;
  font-family: Arial, Helvetica;
  font-size: 14px;
}
.menu li:hover {
  background: #e74c3c;
}
.menu > li > a {
  -webkit-transform: skewX(-25deg);
  padding: 1em 2em;
}
/* Dropdown */
.submenu {
  position: absolute;
  width: 200px;
  left: 50%;
  margin-left: -100px;
  -webkit-transform: skewX(-25deg);
  -webkit-transform-origin: left top;
}
.submenu li {
  background-color: #34495e;
  position: relative;
  overflow: hidden;
}
.submenu > li > a {
  padding: 1em 2em;
}
.submenu > li::after {
  content:'';
  position: absolute;
  top: -125%;
  height: 100%;
  width: 100%;
  box-shadow: 0 0 50px rgba(0, 0, 0, .9);
}
/* Odd stuff */
.submenu > li:nth-child(odd) {
  -webkit-transform: skewX(-25deg) translateX(0);
}
.submenu > li:nth-child(odd) > a {
  -webkit-transform: skewX(25deg);
}
.submenu > li:nth-child(odd)::after {
  right: -50%;
  -webkit-transform: skewX(-25deg) rotate(3deg);
}
/* Even stuff */
.submenu > li:nth-child(even) {
  -webkit-transform: skewX(25deg) translateX(0);
}
.submenu > li:nth-child(even) > a {
  -webkit-transform: skewX(-25deg);
}
.submenu > li:nth-child(even)::after {
  left: -50%;
  -webkit-transform: skewX(25deg) rotate(3deg);
}
/* Show dropdown */
.submenu, .submenu li {
  opacity: 0;
  visibility: hidden;
}
.submenu li {
  transition: .2s ease -webkit-transform;
}
.menu > li:hover .submenu, .menu > li:hover .submenu li {
  opacity: 1;
  visibility: visible;
}
.menu > li:hover .submenu li:nth-child(even) {
  -webkit-transform: skewX(25deg) translateX(15px);
}
.menu > li:hover .submenu li:nth-child(odd) {
  -webkit-transform: skewX(-25deg) translateX(-15px);
}
 
 
 
.foot{
  width: auto;
  height: 300px;
  background: black;
  clear: both;


}

.f_mid1{

  width: 300px;
  margin: 20px;
  padding: 30px;
  float: left;
  background: black;
  color: white;


   

}

.logo{
  width: auto;
  height: 60px;
  margin: 8px;
  padding: 10px
   border-bottom: 7px solid gray;
     background-color:#F5F5DC;   
    text-align: center;     

}



.breking_news{
 width: auto;
  height: 30px;
  margin-top: 8px;
  margin-bottom:8px; 
  padding: 25px
  color:#EC7063;
  
    background-color: #F0F3F4;  


}


a {
text-decoration: none;
}





</style>

 <script src="js/prefixfree.min.js"></script>


  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>


<body>

<div class="head_main"><div class="head_main2"><p style=" text-align: right; padding:10px;"><a  href="<?php echo e(URL::to('/login')); ?>">Login</a> &nbsp&nbsp 
<a  href=""> <img src="<?php echo e(URL::to('/img2/facebook.ico')); ?>" alt="Smiley face" width="50" height="50"></a> &nbsp&nbsp 
<a  href=""> <img src="<?php echo e(URL::to('/img2/twitter.ico')); ?>" alt="Smiley face" width="50" height="50"></a></p>  

</div></div>

</br></br></br>

<ul class="menu cf">
  <li><a href="#">Home</a></li>
  <li>
    <a href="#">Bangladesh</a>
    
  </li>
  <li><a href="#">International</a></li>
  <li><a href="#">Sports</a></li>
    <li><a href="#">Entertainment</a></li>
 
    <li><a href="#">Science</a></li>
 
    <li><a href="#">More</a>

       <ul class="submenu">
      <li><a href="#">Corporate</a></li>
      <li><a href="#">Environment</a></li>
      <li><a href="#">Entertainment</a></li>
      <li><a href="#">Lifestyle</a></li>
    </ul>
    </li>

</ul>

<div class="wrapper_p"><!--wrapper -->

<div class="logo"> <font size="6">71 NEWS</font> </br><?php echo "Today is " . date("Y-m-d") . "<br>"; ?></div><!--for logo -->
 <p style="margin-left:10px; color:white;   background-color: #A93226; width:110px; padding:3px;"> Breaking news: </p>
<div class="breking_news"> <p> <?php echo $__env->yieldContent('breking_news'); ?> </p></div>

	<div class="content_p">
							
                   <?php echo $__env->yieldContent('content'); ?>

	
	</div><!--content -->
	


	<div class="sidebar_p">


         <div class="sidebar_margin">
						 <?php echo $__env->yieldContent('sidebar'); ?>
	
	
	
	
	
	       </div>
	
	
	
	
	</div><!--sidebar_p -->

	</br>



<div class="foot">  <!--  footer-->
         
  
      <div class="f_mid1">
       <p><font size="6">71 NEWS </font></p>

      </div>


      <div class="f_mid1">
        
       <p>© All Rights Reserved
        71 NEWS 1998 - 2016</p>

      </div>

      <div class="f_mid1">
      
              Editor & publisher: Johirul islam. 
              DHOS, Polt-9 ,10 road , MIRPUR-12, Dhaka 1215
             Phone: 8180078-81, Fax: 9130496, E-mail: info@71-NEWS.info
      </div>




</div><!--  footer-->



</div><!--wrapper -->




	
 

					





</body>

