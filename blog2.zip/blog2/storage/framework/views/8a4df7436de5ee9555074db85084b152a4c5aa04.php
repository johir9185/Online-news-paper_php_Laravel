<?php $__env->startSection('title', '71'); ?>



<?php $__env->startSection('content'); ?>
    
    <div class="sp00"> <!--content main middle -->

                           <?php foreach($data00 as $udata): ?>  
                               
													<div class="banner"> <a  href="<?php echo e(URL::to('link_data_bd/' .  $udata->id)); ?>"><div class="img_lef00"><img src="/img2/C.jpg" alt="Smiley face" width="300" height="142" align="left"></div><h3><p style="color:black;"><?php echo e($udata->title); ?></p> </h3>
													 <p style="color:black;"><?php echo e($udata->name); ?></p>  <span class="label label-info">Details</span></a></div>


													
													
                              <?php endforeach; ?>

                  </div>

                  </br>
                

		

           <!--content 1 middle -->
               <div class="sp0">


                     <div class="sp1">

                        <table style="width:700px margin:10px; padding:10px">
							 <?php foreach($data1 as $udata): ?>
								<tr>
									 
									    <td><a href=""> <h5><div class="title_name"><p style="color:black;"><?php echo e($udata->title); ?></p></div></h5>
									 <div class="img_lef"><img src="<?php echo e(URL::to('/img2/'.$udata->img)); ?>" alt="Smiley face" width="140" height="140" align="left"></div><p style="color:black;"><?php echo e($udata->name); ?></p><span class="label label-info">Details</span></a></td>


									
									  </tr>

									   <?php endforeach; ?>
						</table>





                      </div>  

                       <div class="sp2">

                          
						 <table style="width:700px margin:10px; padding:10px">
							 <?php foreach($data2 as $udata): ?>
								<tr>
									 
									    <td><a href=""> <h5><div class="title_name"><p style="color:black;"><?php echo e($udata->title); ?></p></div></h5>
									 <div class="img_lef"><img src="<?php echo e(URL::to('/img2/'.$udata->img)); ?>" alt="Smiley face" width="140" height="140" align="left"></div><p style="color:black;"><?php echo e($udata->name); ?></p><span class="label label-info">Details</span></a></td>


									
									  </tr>

									   <?php endforeach; ?>
						</table>
                    



                      </div>  




               </div>                  



                </br>
               

               <!--content 2 middle -->
         <div class="sp0">


                     <div class="sp1">

                      
                              <table style="width:700px margin:10px; padding:10px">
							 <?php foreach($data3 as $udata): ?>
								<tr>
									 
									    <td><a href=""> <h5><div class="title_name"><p style="color:black;"><?php echo e($udata->title); ?></p></div></h5>
									 <div class="img_lef"><img src="<?php echo e(URL::to('/img2/'.$udata->img)); ?>" alt="Smiley face" width="140" height="140" align="left"></div><p style="color:black;"><?php echo e($udata->name); ?></p><span class="label label-info">Details</span></a></td>


									
									  </tr>

									   <?php endforeach; ?>
						</table>
                    




                      </div>  

                       <div class="sp2">


                         				<!--list view by table row -->
											
												<table rules="rows" style=" margin:10px; padding:10px">
												  <?php foreach($data4 as $udata): ?>
														<tr>
															<td><a href=""> <div class="img_lef2"><img src="<?php echo e(URL::to('/img2/'.$udata->img)); ?>"  width="40px" height="40px" align="left"></a>
															</div> </td>
															<td><a href=""> <p style="color:black;"><?php echo e($udata->name); ?></p></a> </td>
														</tr>
												 <?php endforeach; ?>		 
												</table>



                      </div>  




               </div>              
                 </br>
                 
    <!--content 3 middle -->
         <div class="sp0">


                     <div class="sp1">

                         <table style="width:700px margin:10px; padding:10px">
							 <?php foreach($data5 as $udata): ?>
								<tr>
									 
									    <td><a href=""> <h5><div class="title_name"><p style="color:black;"><?php echo e($udata->title); ?></p></div></h5>
									 <div class="img_lef"><img src="<?php echo e(URL::to('/img2/'.$udata->img)); ?>" alt="Smiley face" width="140" height="140" align="left"></div><p style="color:black;"><?php echo e($udata->name); ?></p><span class="label label-info">Details</span></a></td>


									
									  </tr>

									   <?php endforeach; ?>
						</table>





                      </div>  

                       <div class="sp2">


                      <table style="width:700px margin:10px; padding:10px">
							 <?php foreach($data6 as $udata): ?>
								<tr>
									 
									    <td><a href=""> <h5><div class="title_name"><p style="color:black;"><?php echo e($udata->title); ?></p></div></h5>
									 <div class="img_lef"><img src="<?php echo e(URL::to('/img2/'.$udata->img)); ?>" alt="Smiley face" width="140" height="140" align="left"></div><p style="color:black;"><?php echo e($udata->name); ?></p><span class="label label-info">Details</span></a></td>


									
									  </tr>

									   <?php endforeach; ?>
						</table>



                      </div>  




               </div>                 

               </br>
                
						







<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>



       <?php foreach($data1 as $udata): ?>
								
									 
						
	<img src="<?php echo e(URL::to('/img2/'.$udata->img)); ?>" alt="Smiley face" width="250" height="400">
 </br> </br>
								
									
	   <?php endforeach; ?>



  <div class="table-responsive">
  	<img src="<?php echo e(URL::to('/img2/salat.JPG')); ?>" alt="Smiley face" width="250" height="100">
 </br>
  <table class="table">
    <thead>
      <tr>
     
        <th>Name</th>
		<th>Time </th>
   
      </tr>
    </thead>
    <tbody>
       <?php foreach($salat as $udata): ?>
      <tr>
      
        <td>Fozor</td>
		<td><?php echo e($udata->fozor); ?></td>
     
      </tr>
    </tbody>

<tbody>
  
      <tr>
      
        <td>Zohor</td>
		<td><?php echo e($udata->zohor); ?></td>
     
      </tr>
    </tbody>
<tbody>
      <tr>
      
        <td>Asor</td>
		<td><?php echo e($udata->asor); ?></td>
     
      </tr>
    </tbody>

    <tbody>
      <tr>
      
        <td>Magrib</td>
		<td><?php echo e($udata->magrib); ?></td>
     
      </tr>
    </tbody>

    <tbody>
      <tr>
      
        <td>Esa</td>
		<td><?php echo e($udata->esa); ?></td>
     
      </tr>
           <?php endforeach; ?>
    </tbody>
  </table>
  </div>

 </br> </br>
  <?php foreach($data1 as $udata): ?>
								
									 
						
	<img src="<?php echo e(URL::to('/img2/'.$udata->img)); ?>" alt="Smiley face" width="250" height="400">
 </br> </br>
								
									
	   <?php endforeach; ?>



	   

  
<?php $__env->stopSection(); ?>





<?php $__env->startSection('breking_news'); ?>




<marquee behavior="scroll" direction="right" onmouseover="this.stop();" onmouseout="this.start();">

     <?php foreach($breaking as $udata): ?>

           <?php echo e($udata->name); ?>

       <?php endforeach; ?>

</marquee>



<?php $__env->stopSection(); ?>



<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>