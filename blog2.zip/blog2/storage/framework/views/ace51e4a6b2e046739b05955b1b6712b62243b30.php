<?php $__env->startSection('title', '71'); ?>



<?php $__env->startSection('content'); ?>
    
  <div class="sp00"> <!--content main middle -->

                           <?php foreach($data1 as $udata): ?>  
                               
													<div class="banner"> 
														<div class="img_lef00">
															<img src="/img2/C.jpg" alt="Smiley face" width="300" height="142" align="left">
														</div><h3><p style="color:black;"><?php echo e($udata->title); ?></p> </h3>
													 <p style="color:black;"><?php echo e($udata->name); ?></p><br>
                                                       <p style="color:black;"><?php echo e($udata->des); ?></p>

													</div>


													
													
                              <?php endforeach; ?>

                  </div>

                  </br>
                  <hr>

		

         

               </br>
                  <hr>
						







<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>



       
                
                   
            
  <img src="<?php echo e(URL::to('/img2/C.jpg')); ?>" alt="Smiley face" width="250" height="500">
 </br> </br>

   <img src="<?php echo e(URL::to('/img2/C.jpg')); ?>" alt="Smiley face" width="250" height="500">
 </br> </br>

   <img src="<?php echo e(URL::to('/img2/C.jpg')); ?>" alt="Smiley face" width="250" height="500">
 </br> </br>


   <img src="<?php echo e(URL::to('/img2/C.jpg')); ?>" alt="Smiley face" width="250" height="500">
 </br> </br>


 </br> </br>

 

                  
                  
  



<?php $__env->stopSection(); ?>
<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>