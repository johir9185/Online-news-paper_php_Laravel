<?php $__env->startSection('title', '71'); ?>



<?php $__env->startSection('content'); ?>
    
  <div class="sp00"> <!--content main middle -->

                           <?php foreach($data1 as $udata): ?>  
                               
													<div class="banner"> 
														<div class="img_lef00">
															<img src="<?php echo e(URL::to('/images/'.$udata->img)); ?>" alt="Smiley face" width="300" height="142" align="left">
														</div><h3><p style="color:black;"><?php echo e($udata->title); ?></p> </h3>
													<br>
                                                       <p style="color:black;"><?php echo e($udata->des); ?></p>

													</div>


													
													
                              <?php endforeach; ?>

                  </div>

                  </br>
                  <hr>

		

         

               </br>
                  <hr>
						







<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>



       <?php foreach($add1_2 as $udata): ?>
                
                   
            
  <img src="<?php echo e(URL::to('/add_f/'.$udata->name)); ?>" alt="Smiley face" width="250" height="400">
 </br> </br>
                
                  
     <?php endforeach; ?>



  <div class="table-responsive">
    <img src="<?php echo e(URL::to('/img2/salat.JPG')); ?>" alt="Smiley face" width="250" height="100">
 </br>
  <table class="table">
    <thead>
      <tr>
     
        <th>Name</th>
    <th>Time </th>
   
      </tr>
    </thead>
    <tbody>
       <?php foreach($salat as $udata): ?>
      <tr>
      
        <td>Fozor</td>
    <td><?php echo e($udata->fozor); ?></td>
     
      </tr>
    </tbody>

<tbody>
  
      <tr>
      
        <td>Zohor</td>
    <td><?php echo e($udata->zohor); ?></td>
     
      </tr>
    </tbody>
<tbody>
      <tr>
      
        <td>Asor</td>
    <td><?php echo e($udata->asor); ?></td>
     
      </tr>
    </tbody>

    <tbody>
      <tr>
      
        <td>Magrib</td>
    <td><?php echo e($udata->magrib); ?></td>
     
      </tr>
    </tbody>

    <tbody>
      <tr>
      
        <td>Esa</td>
    <td><?php echo e($udata->esa); ?></td>
     
      </tr>
           <?php endforeach; ?>
    </tbody>
  </table>
  </div>

 </br> </br>
  <?php foreach($add3_4 as $udata): ?>
                
                   
            
  <img src="<?php echo e(URL::to('/add_f/'.$udata->name)); ?>" alt="Smiley face" width="250" height="400">
 </br> </br>
                
                  
     <?php endforeach; ?>



     

  
<?php $__env->stopSection(); ?>





<?php $__env->startSection('breking_news'); ?>




<marquee behavior="scroll" direction="right" onmouseover="this.stop();" onmouseout="this.start();">

     <?php foreach($breaking as $udata): ?>

           <?php echo e($udata->name); ?>

       <?php endforeach; ?>

</marquee>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('master', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>