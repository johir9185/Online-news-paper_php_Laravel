<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-md-8 col-md-offset-2">
            <div class="panel panel-default">
                <div class="panel-heading">Register</div>
                <div class="panel-body">
                    <form class="form-horizontal" role="form" method="POST"  action="<?php echo e(url('/chk_page_international_post')); ?>">
                        <?php echo e(csrf_field()); ?>


                        <div class="table-responsive">
								  <table class="table">
								    <thead>
								      <tr>
								       
								        <th>ID</th>
								        <th>Title</th>
								        <th>Publication</th>
								        <th>Publish</th>
								        <th>Unpublish</th>
								      </tr>
								    </thead>
								     <?php foreach($data as $udata): ?>
								    <tbody>
								      <tr>
								     
								        <td><?php echo e($udata->id); ?></td>
								        <td><?php echo e($udata->title); ?></td>
								       
								         <td><?php if(($udata->pub) == 1): ?>   

                                                 publication
                                            <?php else: ?>
                                             unpublication
                                             <?php endif; ?>
								         </td>
								        <td> <input type="checkbox" name="publication[]" value="<?php echo e($udata->id); ?>" ></td>
								        <td><input type="checkbox" name="unpublication[]" value="<?php echo e($udata->id); ?>" ></td>
								      </tr>
								    </tbody>
								    	 <?php endforeach; ?>		
								  </table>
					   </div>

                        

                        <div class="form-group">
                            <div class="col-md-6 col-md-offset-4">
                                <button type="submit" class="btn btn-primary">
                                    <i class="fa fa-btn fa-user"></i> Update
                                </button>
                            </div>
                        </div>


                         <div class="col-md-12">
                            <?php if(Session::has('flash_message_publication_data')): ?>
                            <div class="alert alert-success">
                                <center><h3><?php echo e(Session::get('flash_message_publication_data')); ?><h3></center>
                                <?php echo e(Session::forget('flash_message_publication_data')); ?>

                            </div>
                        <?php endif; ?>
                    </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('master2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>